#include "config.h"

/*! \file 
    \ingroup GLT
    
    $Id: config.cpp,v 1.5 2002/10/09 15:09:38 nigels Exp $
    
    $Log: config.cpp,v $
    Revision 1.5  2002/10/09 15:09:38  nigels
    Added RCS Id and Log tags


*/

