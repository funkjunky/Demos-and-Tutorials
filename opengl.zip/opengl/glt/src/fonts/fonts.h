#ifndef GLT_FONTS_H
#define GLT_FONTS_H

extern unsigned char antique14Font[];
extern unsigned char art16Font[];
extern unsigned char broadway14Font[];
extern unsigned char courier14Font[];
extern unsigned char decorate16Font[];
extern unsigned char iso14Font[];
extern unsigned char lcd14Font[];
extern unsigned char mac16Font[];
extern unsigned char mac8Font[];
extern unsigned char police16Font[];
extern unsigned char roman14Font[];
extern unsigned char sanserif14Font[];
extern unsigned char spranto14Font[];
extern unsigned char thindemo14Font[];
extern unsigned char vga14Font[];
extern unsigned char vga8Font[];
extern unsigned char wiggly16Font[];

#endif
