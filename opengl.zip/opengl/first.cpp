#include <iostream>
#include <string>
#include "gl/glu.h"

using namespace std;

void display(void)
{
	//glclear(GL_COLOR_BUFFER_BIT);
	//glflush();
}
